#engine v8
#include <pjsr/DataType.jsh>
#feature-id Lerager > SubframeReview
#feature-info Inspect, measure, and flag light frames. Includes an interactive quality graph, an adjustable preview, and a user guide.

// Version: 0.26
// (c) Morten Lerager

(function () {
   "use strict";

   const bayerPatterns = ["RGGB", "BGGR", "GRBG", "GBRG"];
   const cacheLimit = 3;
   const spaceKey = 0x20;
   const layoutKey = "Lerager/SubframeReview/Layout/";

   function readLayoutValue(key, fallback) {
      const value = Settings.read(layoutKey + key, DataType_Int32);
      return Number.isInteger(value) && value > 0 ? value : fallback;
   }

   function processEnum(type, name) {
      const value = type[name];
      return value === undefined ? type.prototype[name] : value;
   }

   function normalizePattern(value) {
      return String(value).replace(/['"\s]/g, "").toUpperCase();
   }

   function bayerPattern(window) {
      const view = window.mainView;
      const property = "PCL:CFASourcePattern";
      if (typeof view.hasProperty === "function" && view.hasProperty(property)) {
         const pattern = normalizePattern(view.propertyValue(property));
         if (bayerPatterns.includes(pattern))
            return pattern;
      }
      for (const keyword of window.keywords) {
         if (keyword.name.toUpperCase() === "BAYERPAT") {
            const pattern = normalizePattern(keyword.value);
            if (bayerPatterns.includes(pattern))
               return pattern;
         }
      }
      return "";
   }

   function stretchPreview(view, adjustment) {
      const backgroundTarget = 0.25 * Math.pow(2, adjustment / 50);
      const image = view.image;
      const channels = image.isColor ? 3 : 1;
      const identity = [0, 0.5, 1, 0, 1];
      const rows = [identity, identity, identity, identity, identity];
      for (let channel = 0; channel < channels; ++channel) {
         image.selectedChannel = channel;
         const median = image.median();
         const shadows = Math.max(0, median - 2.8 * 1.4826 * image.MAD());
         if (median > shadows && median < 1)
            rows[channels === 1 ? 3 : channel] = [shadows, Math.mtf(backgroundTarget, median - shadows), 1, 0, 1];
      }
      image.resetSelections();
      const histogram = new HistogramTransformation;
      histogram.H = rows;
      if (!histogram.executeOn(view, false))
         throw new Error("Could not apply the preview stretch.");
   }

   function readPreview(path, adjustment) {
      const opened = ImageWindow.open(path, "", "raw cfa");
      if (!opened.length)
         throw new Error("Could not open the image.");

      let colorWindow = null;
      try {
         const source = opened[0];
         let view = source.mainView;
         let description = "RGB";
         if (!view.image.isColor) {
            const pattern = bayerPattern(source);
            description = "Grayscale · No Bayer pattern found";
            if (pattern) {
               const debayer = new Debayer;
               debayer.cfaPattern = processEnum(Debayer, pattern);
               debayer.debayerMethod = processEnum(Debayer, "Bilinear");
               debayer.showImages = false;
               debayer.evaluateNoise = false;
               debayer.evaluateSignal = false;
               debayer.noGUIMessages = true;
               if (!debayer.executeOn(view, false))
                  throw new Error("Debayer failed for " + pattern + ".");
               colorWindow = ImageWindow.windowById(debayer.outputImage);
               if (!colorWindow || colorWindow.isNull)
                  throw new Error("PixInsight did not return a debayered preview.");
               view = colorWindow.mainView;
               description = "Debayered RGB (" + pattern + ")";
            }
         }
         stretchPreview(view, adjustment);
         return { bitmap: view.image.render(), description: description };
      } finally {
         if (colorWindow && !colorWindow.isNull)
            colorWindow.forceClose();
         for (const window of opened)
            window.forceClose();
      }
   }

   function openHelp() {
      const help = new Dialog;
      help.windowTitle = "Subframe Review Help";
      const web = new WebView(help);
      const guide = [
         "<!doctype html>\n",
         "<html lang=\"en\">\n",
         "<head>\n",
         "<meta charset=\"utf-8\">\n",
         "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n",
         "<title>Subframe Review \u00b7 User Guide</title>\n",
         "<style>\n",
         ":root{color-scheme:dark;--bg:#111722;--panel:#1b2635;--text:#eaf0f7;--muted:#b8c6d7;--blue:#8acafa;--orange:#ffb15b;--red:#ff817b}\n",
         "*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.6 system-ui,sans-serif}main{max-width:900px;margin:auto;padding:28px 28px 48px}header{padding:30px;background:linear-gradient(125deg,#1d354d,#1b2635);border-radius:16px}h1{font-size:clamp(28px,6vw,46px);line-height:1.1;margin:0 0 12px}h2{line-height:1.25;margin:32px 0 12px}p{margin:8px 0 14px}header p,figcaption,footer{color:var(--muted)}nav{display:flex;gap:16px;flex-wrap:wrap;margin:18px 0}a{color:var(--blue)}figure{margin:16px 0;background:var(--panel);padding:16px;border-radius:12px}svg{width:100%;height:auto;display:block}figcaption{font-size:.9rem;margin-top:8px}table{width:100%;border-collapse:collapse}th,td{padding:8px 10px;text-align:left;vertical-align:top;border-bottom:1px solid #33445a}th{color:var(--blue)}kbd{font:inherit;white-space:nowrap;background:#29384a;border-radius:4px;padding:1px 5px}.note{border-left:3px solid var(--orange);padding:10px 14px;background:var(--panel)}footer{margin-top:32px;font-size:.9rem}\n",
         "</style>\n",
         "</head>\n",
         "<body><main>\n",
         "<header><h1>Subframe Review</h1><p>Inspect, measure, and flag light frames in PixInsight.</p></header>\n",
         "<nav aria-label=\"Contents\"><a href=\"#review\">Review lights</a><a href=\"#measure\">Read the measurements</a><a href=\"#flag\">Flag frames</a><a href=\"#files\">Move or delete</a><a href=\"#install\">Install native help</a></nav>\n",
         "<section id=\"review\">\n",
         "<h2>Review lights</h2>\n",
         "<p>Choose <strong>Add Lights\u2026</strong> to open FITS or XISF files. You can add more files from another folder. Files already in the list are skipped. Raw color frames with Bayer metadata are debayered for the preview. The preview leaves the saved image data unchanged.</p>\n",
         "<table><thead><tr><th>Action</th><th>Control</th></tr></thead><tbody>\n",
         "<tr><td>Browse frames</td><td><kbd>\u2191</kbd> or <kbd>\u2193</kbd> in the file list</td></tr>\n",
         "<tr><td>Flag or unflag a frame</td><td>Double-click its row or press <kbd>Space</kbd></td></tr>\n",
         "<tr><td>Zoom or pan</td><td>Scroll over the image to zoom. Drag the image to pan.</td></tr>\n",
         "<tr><td>Fit or show at 100%</td><td><kbd>0</kbd> for Fit, <kbd>1</kbd> for 100%</td></tr>\n",
         "<tr><td>Adjust preview brightness</td><td>Move <strong>STF</strong> left to darken or right to brighten. <strong>Reset STF</strong> restores the default stretch.</td></tr>\n",
         "</tbody></table>\n",
         "<p>Drag the divider or the right edge of the file list to resize it. The script remembers the window size and list width when you close it.</p>\n",
         "</section>\n",
         "<section id=\"measure\"><h2>Read the measurements</h2>\n",
         "<p>Choose <strong>Measure</strong> to run PixInsight\u2019s SubframeSelector on the original files. The table and graph show the results for each frame.</p>\n",
         "<table><thead><tr><th>Metric</th><th>What to look for</th><th>Flags</th></tr></thead><tbody>\n",
         "<tr><td>FWHM px</td><td>Larger values indicate broader star profiles.</td><td>Above</td></tr>\n",
         "<tr><td>Eccentricity</td><td>Zero is round. Values closer to one indicate elongation.</td><td>Above</td></tr>\n",
         "<tr><td>Median</td><td>Higher values indicate a brighter typical pixel. Compare frames from the same filter and exposure.</td><td>Above</td></tr>\n",
         "<tr><td>Stars</td><td>A sudden drop can reveal reduced transparency or a poor exposure.</td><td>Below</td></tr>\n",
         "</tbody></table>\n",
         "</section>\n",
         "<section id=\"flag\"><h2>Flag frames</h2>\n",
         "<figure>\n",
         "<svg viewBox=\"0 0 700 158\" role=\"img\" aria-label=\"Example FWHM graph. Two orange frames lie above the red limit. A white outline identifies the selected frame.\">\n",
         "<path d=\"M64 19v103h600\" stroke=\"#a3abb7\" fill=\"none\"/><path d=\"M64 51h600\" stroke=\"#ff817b\" stroke-width=\"2\"/>\n",
         "<g fill=\"#8acafa\"><circle cx=\"110\" cy=\"100\" r=\"5\"/><circle cx=\"181\" cy=\"84\" r=\"5\"/><circle cx=\"323\" cy=\"90\" r=\"5\"/><circle cx=\"394\" cy=\"104\" r=\"5\"/><circle cx=\"536\" cy=\"74\" r=\"5\"/><circle cx=\"607\" cy=\"93\" r=\"5\"/></g>\n",
         "<g fill=\"#ffb15b\"><circle cx=\"252\" cy=\"30\" r=\"5\"/><circle cx=\"465\" cy=\"36\" r=\"5\"/></g><circle cx=\"252\" cy=\"30\" r=\"9\" fill=\"none\" stroke=\"white\" stroke-width=\"2\"/>\n",
         "<g fill=\"#b8c6d7\" font-size=\"14\" font-family=\"system-ui,sans-serif\"><text x=\"5\" y=\"24\">FWHM</text><text x=\"70\" y=\"144\">Frames in capture order</text><text x=\"573\" y=\"43\" fill=\"#ff817b\">Limit</text></g>\n",
         "</svg>\n",
         "<figcaption>An orange point is flagged. The larger point identifies the selected frame. Click any point to inspect its image.</figcaption>\n",
         "</figure>\n",
         "<p>Choose a metric and drag the red line. For FWHM, Eccentricity, and Median, drag down from the top. For Stars, drag up from the bottom. Each metric retains its limit when you switch graphs.</p>\n",
         "<p><strong>Total flagged</strong> counts each flagged frame once across all metrics and manual flags. The total is visible even before measurement. You can override a graph flag by double-clicking its row. <strong>Keep flags &amp; reset limits</strong> retains the current flags and returns every threshold to its starting position.</p>\n",
         "</section>\n",
         "<section id=\"files\"><h2>Move or delete flagged frames</h2>\n",
         "<p><strong>Move flagged\u2026</strong> opens the first flagged file\u2019s source folder. Choose a different folder or create a subfolder. The script reports the destination and how many files were moved. Files already present in the destination are skipped.</p>\n",
         "<p class=\"note\"><strong>Delete flagged\u2026</strong> permanently deletes the flagged files after confirmation. If you want to review the files again later, move them to a separate folder.</p>\n",
         "</section>\n",
         "<section id=\"install\"><h2>Install help in Process Explorer</h2>\n",
         "<ol><li>Register the extracted script folder through <strong>Script \u2192 Feature Scripts\u2026 \u2192 Add</strong>.</li><li>Open <strong>Script \u2192 Development \u2192 Documentation Compiler</strong>, add <strong>SubframeReview.pidoc</strong>, and run the compiler.</li><li>Open the documentation for <strong>SubframeReview</strong> under <strong>Lerager</strong> in Process Explorer.</li></ol>\n",
         "<p>The <strong>Help</strong> button opens this guide directly in the script. You can also open the HTML file separately.</p>\n",
         "</section>\n",
         "<footer>(c) Morten Lerager \u00b7 Subframe Review 0.26</footer>\n",
         "</main></body></html>\n",
      ].join("");
      web.setHTML(guide);
      const closeHelp = new PushButton(help);
      closeHelp.text = "Close";
      closeHelp.onClick = () => help.ok();
      const actions = new HorizontalSizer;
      actions.addStretch();
      actions.add(closeHelp);
      help.sizer = new VerticalSizer;
      help.sizer.margin = 8;
      help.sizer.spacing = 8;
      help.sizer.add(web, 1);
      help.sizer.add(actions);
      help.resize(880, 680);
      help.execute();
   }

   class ReviewDialog extends Dialog {
      constructor() {
         super();

         const dialog = this;
         const cache = new Map();
         const loaded = new Map();
         let frame = null;
         let stretchAdjustment = 0;
         let preview = null;
         let zoom = 0;
         let centerX = 0.5;
         let centerY = 0.5;
         let drag = null;
         const savedListWidth = readLayoutValue("ListWidth", 0);
         let manualListWidth = savedListWidth > 0;
         let filenameWidth = 265;
         let display = null;

         const minimumPreviewWidth = 320;
         const canvas = new Control(this);
         canvas.setMinSize(minimumPreviewWidth, 400);
         const list = new TreeBox(this);
         list.numberOfColumns = 2;
         list.setHeaderText(0, "Light frame");
         list.setHeaderText(1, "Status");
         list.rootDecoration = false;
         list.alternateRowColor = true;
         const statusWidth = list.font.width("Flagged") + 24;
         const listPadding = 24;
         const metricHeaders = ["FWHM px", "Eccentricity", "Median", "Stars"];
         const metricWidths = metricHeaders.map(header => list.font.width(header) + 20);
         let metricsWidth = 0;
         const minimumListWidth = 92 + statusWidth + listPadding;
         const initialWidth = Math.max(minimumListWidth, savedListWidth || 435);
         list.setFixedWidth(initialWidth);
         list.setColumnWidth(0, savedListWidth ? initialWidth - statusWidth - listPadding : filenameWidth);
         list.setColumnWidth(1, statusWidth);
         const status = new Label(this);
         status.frameStyle = FrameStyle.Box;
         status.margin = 5;
         let statusDetail = "Add FITS or XISF light frames.";
         let totalFlagged = 0;
         function showStatus(detail = statusDetail) {
            statusDetail = detail;
            status.text = detail + "   ·   Total flagged: " + totalFlagged;
         }
         showStatus();

         function renderScale() {
            const bitmap = preview.bitmap;
            return zoom || Math.min(canvas.width / bitmap.width, canvas.height / bitmap.height, 1);
         }

         function clampCenter() {
            const scale = renderScale();
            const bitmap = preview.bitmap;
            const halfX = Math.min(0.5, canvas.width / (2 * bitmap.width * scale));
            const halfY = Math.min(0.5, canvas.height / (2 * bitmap.height * scale));
            centerX = Math.max(halfX, Math.min(1 - halfX, centerX));
            centerY = Math.max(halfY, Math.min(1 - halfY, centerY));
         }

         function redraw() {
            if (canvas.width < 1 || canvas.height < 1)
               return;
            const next = new Bitmap(canvas.width, canvas.height);
            const graphics = new Graphics(next);
            try {
               graphics.fillRect(new Rect(0, 0, canvas.width, canvas.height), new Brush(0xff151515));
               if (preview) {
                  clampCenter();
                  const scale = renderScale();
                  const width = preview.bitmap.width * scale;
                  const height = preview.bitmap.height * scale;
                  const x = canvas.width / 2 - centerX * width;
                  const y = canvas.height / 2 - centerY * height;
                  graphics.drawScaledBitmap(new Rect(Math.round(x), Math.round(y),
                     Math.round(x + width), Math.round(y + height)), preview.bitmap);
               }
            } finally {
               graphics.end();
            }
            display = next;
            canvas.update();
         }

         canvas.onPaint = function () {
            if (display) {
               const graphics = new Graphics(canvas);
               try {
                  graphics.drawBitmap(0, 0, display);
               } finally {
                  graphics.end();
               }
            }
         };
         canvas.onResize = redraw;

         canvas.onMousePress = function (x, y, button) {
            if (preview && button === MouseButton.Left)
               drag = { x, y, centerX, centerY };
         };
         canvas.onMouseMove = function (x, y, buttons) {
            if (!preview || !drag || !(buttons & MouseButton.Left))
               return;
            const scale = renderScale();
            centerX = drag.centerX - (x - drag.x) / (preview.bitmap.width * scale);
            centerY = drag.centerY - (y - drag.y) / (preview.bitmap.height * scale);
            redraw();
         };
         canvas.onMouseRelease = function () { drag = null; };

         function select(node) {
            if (!node || !node.lightFrame || frame === node.lightFrame)
               return;
            frame = node.lightFrame;
            drag = null;
            refreshPreview();
            graph.update();
         }

         function refreshPreview() {
            const requested = frame;
            if (!requested)
               return;
            const adjustment = stretchAdjustment;
            try {
               const path = frame.path;
               let entry = cache.get(path);
               if (entry)
                  cache.delete(path);
               else
                  entry = readPreview(path, adjustment);
               if (stretchAdjustment !== adjustment)
                  return;
               cache.set(path, entry);
               if (cache.size > cacheLimit)
                  cache.delete(cache.keys().next().value);
               if (frame !== requested)
                  return;
               preview = entry;
               showStatus(entry.description + "   ·   " + entry.bitmap.width + " × " + entry.bitmap.height);
            } catch (error) {
               if (frame !== requested || stretchAdjustment !== adjustment)
                  return;
               preview = null;
               showStatus("Preview unavailable · " + error.message);
            }
            redraw();
         }

         function toggleFlagged(node) {
            if (!node || !node.lightFrame)
               return;
            const item = node.lightFrame;
            item.manualFlag = !isFlagged(node);
            updateFlags();
         }

         function button(title, action, parent = dialog) {
            const control = new PushButton(parent);
            control.text = title;
            control.onClick = action;
            return control;
         }

         function maximumListWidth() {
            return list.width + canvas.width - minimumPreviewWidth;
         }

         function resizeFileList(requestedWidth) {
            const width = Math.max(minimumListWidth,
               Math.min(Math.round(requestedWidth), maximumListWidth()));
            if (width !== list.width)
               list.setFixedWidth(width);
            list.setColumnWidth(0, Math.max(1, width - statusWidth - metricsWidth - listPadding));
            list.setColumnWidth(1, statusWidth);
         }

         function fileName(path) {
            return path.split(/[\\/]/).pop();
         }

         function addFileRow(item) {
            const node = new TreeBoxNode(list);
            node.lightFrame = item;
            node.setText(0, fileName(item.path));
            node.setToolTip(0, item.path);
            node.setText(1, isFlagged(node) ? "Flagged" : "Keep");
            if (metricsWidth) {
               metricHeaders.forEach((header, index) => {
                  const value = item.metrics?.[index];
                  node.setText(index + 2, Number.isFinite(value) ? value.toFixed(decimals[index]) : "—");
               });
            }
            loaded.set(item.path, node);
            return node;
         }

         const add = button("Add Lights…", function () {
            const files = new OpenFileDialog;
            files.caption = "Select light frames";
            files.multipleSelections = true;
            files.filters = [["Astro images", "*.fit", "*.fits", "*.fts", "*.xisf"]];
            if (!files.execute())
               return;

            let first = null;
            for (const path of files.fileNames) {
               if (loaded.has(path))
                  continue;
               const name = fileName(path);
               filenameWidth = Math.max(filenameWidth, list.font.width(name) + 24);
               const node = addFileRow({ path });
               if (!first)
                  first = node;
            }
            if (first && !manualListWidth)
               resizeFileList(Math.max(list.width, filenameWidth + statusWidth + metricsWidth + listPadding));
            measure.enabled = loaded.size > 0;
            if (!frame && first) {
               list.currentNode = first;
               select(first);
            }
            if (typeof list.focus === "function")
               list.focus();
         });

         const measure = button("Measure", function () {
            const paths = Array.from(loaded.keys());
            if (!paths.length)
               return;
            measure.enabled = false;
            add.enabled = false;
            dialog.enabled = false;
            const previousStatus = statusDetail;
            showStatus("Measuring " + paths.length + " light frames…");
            try {
               processEvents();
               const selector = new SubframeSelector;
               selector.routine = processEnum(SubframeSelector, "MeasureSubframes");
               selector.nonInteractive = true;
               selector.noNoiseAndSignalWarnings = true;
               selector.subframeScale = 1;
               selector.dataUnit = processEnum(SubframeSelector, "Normalized");
               selector.subframes = paths.map(path => [true, path, "", ""]);
               const succeeded = selector.executeGlobal();
               const rows = selector.measurements || [];
               if (!succeeded && !rows.length)
                  throw new Error("SubframeSelector did not return measurements.");

               if (!metricsWidth) {
                  list.numberOfColumns = 2 + metricHeaders.length;
                  metricHeaders.forEach((header, index) => {
                     list.setHeaderText(index + 2, header);
                     list.setColumnWidth(index + 2, metricWidths[index]);
                  });
                  metricsWidth = metricWidths.reduce((sum, width) => sum + width, 0);
                  resizeFileList(manualListWidth ? list.width :
                     Math.max(list.width, filenameWidth + statusWidth + metricsWidth + listPadding));
               }
               for (const node of loaded.values())
                  node.lightFrame.metrics = null;
               for (const node of loaded.values())
                  metricHeaders.forEach((header, index) => node.setText(index + 2, "—"));

               const nodesByPath = new Map(paths.map(path => [path.replace(/\\/g, "/"), loaded.get(path)]));
               let measured = 0;
               for (const row of rows) {
                  const node = nodesByPath.get(String(row[3]).replace(/\\/g, "/"));
                  if (!node)
                     continue;
                  const values = [[row[5], 2], [row[6], 3], [row[10], 5], [row[14], 0]];
                  node.lightFrame.metrics = values.map(([value]) => value);
                  values.forEach(([value, decimals], index) => {
                     node.setText(index + 2, Number.isFinite(value) ? value.toFixed(decimals) : "—");
                  });
                  ++measured;
               }
               if (measured)
                  graphPanel.show();
               refreshGraph();
               showStatus("Measured " + measured + " of " + paths.length + " light frames · " + previousStatus);
            } catch (error) {
               showStatus("Measurement unavailable · " + error.message);
            } finally {
               console.hide();
               dialog.enabled = true;
               add.enabled = true;
               measure.enabled = true;
            }
         });
         measure.enabled = false;
         measure.toolTip = "Measure the original light files with PixInsight SubframeSelector.";

         const graphPanel = new Control(this);
         const graph = new Control(graphPanel);
         graph.setMinSize(280, 140);
         graph.setFixedHeight(140);
         const metric = new ComboBox(graphPanel);
         metricHeaders.forEach(header => metric.addItem(header));
         metric.currentItem = 0;
         const flagSummary = new Label(graphPanel);
         const totalSummary = new Label(graphPanel);
         let plotted = [];
         let threshold = null;
         const limits = metricHeaders.map(() => null);
         let low = 0;
         let high = 1;
         let draggingThreshold = false;
         const decimals = [2, 3, 5, 0];

         function chartBounds() {
            return {
               left: 78, right: Math.max(79, graph.width - 17),
               top: 13, bottom: Math.max(14, graph.height - 24)
            };
         }

         function pointX(index, bounds) {
            return plotted.length === 1 ? (bounds.left + bounds.right) / 2 :
               bounds.left + index * (bounds.right - bounds.left) / (plotted.length - 1);
         }

         function pointY(value, bounds) {
            return bounds.bottom - (value - low) * (bounds.bottom - bounds.top) / (high - low);
         }

         function exceedsLimit(value, limit, index) {
            return limit !== null && Number.isFinite(value) &&
               (index === 3 ? value < limit : value > limit);
         }

         function isFlagged(node) {
            return node.lightFrame.manualFlag ?? limits.some((limit, index) =>
               exceedsLimit(node.lightFrame.metrics?.[index], limit, index));
         }

         function startingLimit() {
            if (!plotted.length)
               return null;
            return metric.currentItem === 3 ? low : high;
         }

         function updateFlags() {
            let count = 0;
            totalFlagged = 0;
            for (const node of loaded.values()) {
               const flagged = isFlagged(node);
               node.setText(1, flagged ? "Flagged" : "Keep");
               if (flagged) {
                  ++totalFlagged;
                  const index = metric.currentItem;
                  if (exceedsLimit(node.lightFrame.metrics?.[index], limits[index], index))
                     ++count;
               }
            }
            const direction = metric.currentItem === 3 ? "Below " : "Above ";
            flagSummary.text = threshold === null ? "No measurements for this metric" :
               direction + threshold.toFixed(decimals[metric.currentItem]) + "   ·   " + count + " flagged for " + metricHeaders[metric.currentItem];
            totalSummary.text = "Total flagged: " + totalFlagged;
            showStatus();
            keepFlags.enabled = limits.some(limit => limit !== null);
            moveFlagged.enabled = deleteFlagged.enabled = totalFlagged > 0;
            graph.update();
         }

         function refreshGraph() {
            const dated = Array.from(loaded.values(), node => ({
               node,
               stamp: node.lightFrame.path.split(/[\\/]/).pop().match(/\d{8}-\d{6}/)?.[0]
            }));
            const chronological = dated.length > 0 && dated.every(item => item.stamp);
            if (chronological)
               dated.sort((a, b) => a.stamp.localeCompare(b.stamp));
            plotted = [];
            low = Infinity;
            high = -Infinity;
            for (const { node } of dated) {
               const value = node.lightFrame.metrics?.[metric.currentItem];
               if (Number.isFinite(value)) {
                  plotted.push({ node, value });
                  low = Math.min(low, value);
                  high = Math.max(high, value);
               }
            }
            if (plotted.length) {
               const padding = Math.max((high - low) * 0.08, Math.pow(10, -decimals[metric.currentItem]));
               const units = Math.pow(10, decimals[metric.currentItem]);
               low = Math.max(0, Math.floor((low - padding) * units) / units);
               high = Math.ceil((high + padding) * units) / units;
            }
            graph.toolTip = chronological ? "Frames in capture order" : "Frames in the order they were added";
            const saved = limits[metric.currentItem];
            if (plotted.length && saved !== null) {
               low = Math.min(low, saved);
               high = Math.max(high, saved);
            }
            threshold = saved ?? startingLimit();
            updateFlags();
         }

         graph.onPaint = function () {
            const g = new Graphics(graph);
            try {
               g.fillRect(new Rect(0, 0, graph.width, graph.height), new Brush(0xff181b20));
               if (!plotted.length)
                  return;
               const b = chartBounds();
               const digits = decimals[metric.currentItem];
               g.pen = new Pen(0xffa3abb7);
               g.drawText(7, b.top + 5, high.toFixed(digits));
               g.drawText(7, b.bottom + 4, low.toFixed(digits));
               g.drawText(b.left, graph.height - 6, graph.toolTip);
               g.pen = new Pen(0xff626b77);
               g.drawLine(b.left, b.top, b.left, b.bottom);
               g.drawLine(b.left, b.bottom, b.right, b.bottom);
               if (threshold !== null) {
                  const y = Math.round(pointY(threshold, b));
                  g.pen = new Pen(0xfff06d68, 2);
                  g.drawLine(b.left, y, b.right, y);
               }
               plotted.forEach(({ node, value }, index) => {
                  const x = Math.round(pointX(index, b));
                  const y = Math.round(pointY(value, b));
                  const selected = node.lightFrame === frame;
                  const size = selected ? 3 : 2;
                  const color = isFlagged(node) ? 0xffffa654 : 0xff83c7f8;
                  if (selected)
                     g.fillRect(new Rect(x - 4, y - 4, x + 5, y + 5), new Brush(0xfff4f4f4));
                  g.fillRect(new Rect(x - size, y - size, x + size + 1, y + size + 1), new Brush(color));
               });
            } finally {
               g.end();
            }
         };

         function setThreshold(y, bounds) {
            const fraction = Math.max(0, Math.min(1, (bounds.bottom - y) / (bounds.bottom - bounds.top)));
            const value = low + fraction * (high - low);
            threshold = Number(value.toFixed(decimals[metric.currentItem]));
            limits[metric.currentItem] = threshold === startingLimit() ? null : threshold;
            updateFlags();
         }

         graph.onMousePress = function (x, y, mouseButton) {
            if (mouseButton !== MouseButton.Left || !plotted.length)
               return;
            const b = chartBounds();
            if (x < b.left - 7 || x > b.right + 7 || y < b.top - 7 || y > b.bottom + 7)
               return;
            const lineHit = threshold !== null && Math.abs(y - pointY(threshold, b)) <= 5;
            let nearest = null;
            let distance = 64;
            if (!lineHit) {
               plotted.forEach((point, index) => {
                  const dx = x - pointX(index, b);
                  const dy = y - pointY(point.value, b);
                  const squared = dx * dx + dy * dy;
                  if (squared < distance) {
                     distance = squared;
                     nearest = point.node;
                  }
               });
            }
            if (nearest) {
               list.currentNode = nearest;
               select(nearest);
               return;
            }
            draggingThreshold = true;
            setThreshold(y, b);
         };
         graph.onMouseMove = function (x, y, buttons) {
            if (draggingThreshold && (buttons & MouseButton.Left))
               setThreshold(y, chartBounds());
         };
         graph.onMouseRelease = function () { draggingThreshold = false; };

         const keepFlags = button("Keep flags & reset limits", function () {
            for (const node of loaded.values())
               node.lightFrame.manualFlag = isFlagged(node) ? true : undefined;
            limits.fill(null);
            refreshGraph();
         }, graphPanel);
         metric.onItemSelected = refreshGraph;
         const graphControls = new HorizontalSizer;
         graphControls.spacing = 6;
         graphControls.add(metric);
         graphControls.add(flagSummary);
         graphControls.add(totalSummary);
         graphControls.addStretch();
         graphControls.add(keepFlags);
         graphPanel.sizer = new VerticalSizer;
         graphPanel.sizer.spacing = 4;
         graphPanel.sizer.add(graphControls);
         graphPanel.sizer.add(graph);
         const moveFlagged = button("Move flagged…", () => processFlaggedFiles(false));
         const deleteFlagged = button("Delete flagged…", () => processFlaggedFiles(true));
         updateFlags();

         function sameFilePath(a, b) {
            const normalize = path => {
               const normalized = path.replace(/\\/g, "/");
               const drive = normalized.charAt(0).toLowerCase();
               const hasDrive = normalized.charAt(1) === ":" && drive >= "a" && drive <= "z";
               const isNetworkPath = normalized.charAt(0) === "/" && normalized.charAt(1) === "/";
               return hasDrive || isNetworkPath ? normalized.toLowerCase() : normalized;
            };
            return normalize(a) === normalize(b);
         }

         function processFlaggedFiles(permanentDelete) {
            const targets = Array.from(loaded.values())
               .filter(isFlagged)
               .map(node => node.lightFrame.path);
            if (!targets.length)
               return;

            let destination = "";
            if (!permanentDelete) {
               const folder = new GetDirectoryDialog;
               folder.caption = "Choose a folder for flagged light frames";
               folder.initialPath = File.extractDrive(targets[0]) + File.extractDirectory(targets[0]);
               if (!folder.execute())
                  return;
               destination = folder.directoryPath.replace(/[/\\]+$/, "") + "/";
            }

            const title = permanentDelete ? "Delete flagged light frames" : "Move flagged light frames";
            if (!permanentDelete && targets.every(path =>
               sameFilePath(path, destination + fileName(path)))) {
               const message = "No files moved. You selected the source folder. Choose a different folder or create a subfolder.";
               showStatus(message);
               new MessageBox(message, title, StdIcon.Warning, StdButton.Ok).execute();
               return;
            }
            const question = permanentDelete
               ? "Permanently delete " + targets.length + " flagged file(s)?\nThis cannot be undone."
               : "Move " + targets.length + " flagged file(s) to:\n" + destination + "?";
            const confirm = new MessageBox(question, title,
               permanentDelete ? StdIcon.Warning : StdIcon.Question, StdButton.No, StdButton.Yes);
            if (confirm.execute() !== StdButton.Yes)
               return;

            const errors = [];
            let completed = 0;
            for (const path of targets) {
               try {
                  if (!File.exists(path))
                     throw new Error("Source file is missing.");
                  if (permanentDelete) {
                     File.remove(path);
                  } else {
                     const target = destination + fileName(path);
                     if (sameFilePath(path, target))
                        throw new Error("File is already in the selected folder.");
                     if (File.exists(target) || File.directoryExists(target))
                        throw new Error("Destination already exists.");
                     const copied = File.copyFile(target, path);
                     if (copied === false || !File.exists(target))
                        throw new Error("Copy to the destination failed. The source was kept.");
                     try {
                        File.remove(path);
                        if (File.exists(path))
                           throw new Error("The source file is still present.");
                     } catch (error) {
                        throw new Error("Copied to " + target +
                           " but could not remove the source. " + error.message);
                     }
                  }
                  if (File.exists(path))
                     throw new Error("Source file is still present.");
                  loaded.delete(path);
                  cache.delete(path);
                  ++completed;
               } catch (error) {
                  errors.push(fileName(path) + ": " + error.message);
               }
            }
            if (completed)
               rebuildFileList();
            const summary = (permanentDelete ? "Deleted: " : "Moved: ") + completed + " of " + targets.length;
            const result = permanentDelete ? summary : summary + "\nDestination: " + destination;
            showStatus(summary);
            if (errors.length) {
               const details = errors.slice(0, 5).join("\n");
               const remaining = errors.length > 5 ? "\n… and " + (errors.length - 5) + " more." : "";
               new MessageBox(result + "\n\n" + details + remaining,
                  title, StdIcon.Warning, StdButton.Ok).execute();
            } else if (!permanentDelete) {
               new MessageBox(result, title, StdIcon.Information, StdButton.Ok).execute();
            }
         }

         function rebuildFileList() {
            const selectedPath = frame?.path;
            const survivors = Array.from(loaded.values(), node => node.lightFrame);
            list.onCurrentNodeUpdated = null;
            list.clear();
            loaded.clear();
            for (const item of survivors)
               addFileRow(item);

            const next = loaded.get(selectedPath) || loaded.values().next().value;
            if (next)
               list.currentNode = next;
            list.onCurrentNodeUpdated = select;
            if (next) {
               select(next);
            } else {
               frame = null;
               preview = null;
               redraw();
            }
            measure.enabled = loaded.size > 0;
            refreshGraph();
         }

         function setZoom(scale) {
            zoom = scale;
            if (scale === 0)
               centerX = centerY = 0.5;
            redraw();
         }

         function stepZoom(factor, x = canvas.width / 2, y = canvas.height / 2) {
            if (!preview)
               return;
            const bitmap = preview.bitmap;
            const previous = renderScale();
            const fitScale = Math.min(canvas.width / bitmap.width, canvas.height / bitmap.height, 1);
            const scale = Math.min(4, Math.max(fitScale, previous * factor));
            if (scale === previous)
               return;
            const offset = 1 / previous - 1 / scale;
            centerX += (x - canvas.width / 2) * offset / bitmap.width;
            centerY += (y - canvas.height / 2) * offset / bitmap.height;
            setZoom(scale === fitScale ? 0 : scale);
         }

         canvas.onMouseWheel = function (x, y, delta) {
            if (delta)
               stepZoom(delta > 0 ? 1.25 : 0.8, x, y);
         };

         function makeListGrip(outer) {
            const grip = new Control(dialog);
            grip.setFixedWidth(8);
            grip.toolTip = outer ? "Drag left to enlarge the image preview." : "Drag to resize the file list.";
            let start = null;
            grip.onPaint = function () {
               const graphics = new Graphics(grip);
               try {
                  graphics.fillRect(new Rect(3, 0, 5, grip.height), new Brush(0xff808080));
               } finally {
                  graphics.end();
               }
            };
            grip.onMousePress = function (x, y, button) {
               if (button === MouseButton.Left)
                  start = { x, width: list.width };
            };
            grip.onMouseMove = function (x, y, buttons) {
               if (!start || !(buttons & MouseButton.Left))
                  return;
               manualListWidth = true;
               resizeFileList(outer ? start.width + x - start.x : list.width + start.x - x);
            };
            grip.onMouseRelease = function () { start = null; };
            return grip;
         }

         const divider = makeListGrip(false);
         const outerGrip = makeListGrip(true);

         const fit = button("Fit", function () { setZoom(0); });
         const oneToOne = button("100%", function () { setZoom(1); });
         const zoomOut = button("−", function () { stepZoom(1 / 1.25); });
         const zoomIn = button("+", function () { stepZoom(1.25); });
         const close = button("Close", function () { dialog.ok(); });
         list.onCurrentNodeUpdated = select;
         list.onNodeDoubleClicked = function (node) { toggleFlagged(node); };

         const previewKeys = {
            0x2b: () => stepZoom(1.25),        // +
            0x3d: () => stepZoom(1.25),        // =
            0x2d: () => stepZoom(1 / 1.25),    // -
            0x30: () => setZoom(0),            // 0
            0x31: () => setZoom(1)             // 1
         };
         function handleKeys(key) {
            if (key === spaceKey) {
               toggleFlagged(list.currentNode);
               return true;
            }
            const action = previewKeys[key];
            if (!action)
               return false;
            action();
            return true;
         }
         list.onKeyPress = handleKeys;
         this.onKeyPress = handleKeys;
         const shortcuts = new Label(this);
         shortcuts.text = "Double-click / Space: Keep or Flag   ·   Wheel / + / −: Zoom   ·   Drag: Pan   ·   0: Fit   ·   1: 100%";

         const stfLabel = new Label(this);
         stfLabel.text = "STF: 0";
         const stfMidpoint = 50;
         const stfSlider = new Slider(this);
         stfSlider.setRange(0, 2 * stfMidpoint);
         stfSlider.value = stfMidpoint;
         stfSlider.setMinWidth(240);
         stfSlider.tracking = false;
         stfSlider.toolTip = "Adjust preview brightness. 0 uses the default auto stretch.";
         function updateStretch(position) {
            const value = position - stfMidpoint;
            if (value === stretchAdjustment)
               return;
            stretchAdjustment = value;
            stfLabel.text = "STF: " + (value > 0 ? "+" : "") + value;
            cache.clear();
            refreshPreview();
         }

         stfSlider.onValueUpdated = updateStretch;
         const resetStf = button("Reset STF", function () {
            stfSlider.value = stfMidpoint;
            updateStretch(stfMidpoint);
         });
         const stfRow = new HorizontalSizer;
         stfRow.spacing = 6;
         stfRow.add(stfLabel);
         stfRow.add(stfSlider, 1);
         const stfControls = new VerticalSizer;
         stfControls.spacing = 3;
         stfControls.add(resetStf);
         stfControls.add(stfRow);

         const content = new HorizontalSizer;
         content.spacing = 8;
         content.add(canvas, 1);
         content.add(divider);
         content.add(list);
         content.add(outerGrip);
         const controls = new HorizontalSizer;
         controls.spacing = 6;
         controls.add(add);
         controls.add(measure);
         controls.add(fit);
         controls.add(oneToOne);
         controls.add(zoomOut);
         controls.add(zoomIn);
         controls.add(stfControls);
         controls.addStretch();
         controls.add(moveFlagged);
         controls.add(deleteFlagged);
         controls.add(close);

         this.windowTitle = "Subframe Review 0.26";
         this.sizer = new VerticalSizer;
         this.sizer.margin = 10;
         this.sizer.spacing = 8;
         this.sizer.add(content, 1);
         this.sizer.add(graphPanel);
         graphPanel.hide();
         this.sizer.add(status);
         const credit = new Label(this);
         credit.text = "(c) Morten Lerager";
         const footer = new HorizontalSizer;
         footer.spacing = 8;
         footer.add(shortcuts);
         footer.addStretch();
         footer.add(button("Help", openHelp));
         footer.add(credit);
         this.sizer.add(footer);
         this.sizer.add(controls);
         this.resize(readLayoutValue("Width", 1375), readLayoutValue("Height", 860));
         this.saveLayout = function () {
            Settings.write(layoutKey + "Width", DataType_Int32, dialog.width);
            Settings.write(layoutKey + "Height", DataType_Int32, dialog.height);
            Settings.write(layoutKey + "ListWidth", DataType_Int32, list.width);
         };
      }
   }

   console.hide();
   const dialog = new ReviewDialog();
   dialog.execute();
   dialog.saveLayout();
})();
